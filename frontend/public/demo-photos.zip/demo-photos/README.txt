ImageVault demo photos
======================

87 photos for trying out ImageVault. Upload the whole folder (or drag the zip's
photos onto the page), wait for the AI status to finish, then look around.

Duplicates page
  norway-fjord (copy).jpg, london-at-night (1).jpg   exact copies
  norway-fjord-whatsapp.jpg, beach-palm-trees-whatsapp.jpg   resized and compressed
  norway-fjord-edited.jpg, sunset-over-field-filter.jpg      colours edited
  pug-in-blanket-small.jpg, strawberries-compressed.jpg      smaller / lower quality copies
  pelican-burst-1..5.jpg   a burst taken one second apart; ImageVault picks the sharpest
  taj-mahal-*.jpg          four different shots of the same place ("Same subject")

People page
  Biden, Harris, Obama, Kalpana Chawla and Sunita Williams each appear in several photos,
  including group photos where they have to be found among other faces.

Albums page
  Made automatically: Beach, Mountains, Food & drink, Pets, Wildlife, City, Landmarks,
  Nature, Snow, Sunsets and People.

Photos page
  Smart search: try "dog", "pizza", "a bridge at night" or "snowy mountains".
  Text search (the normal search box): try "vegas", "honey" or "stop": ImageVault reads
  the words on signs in las-vegas-sign.jpg, malibu-feed-bin.jpg and stop-sign-and-mailboxes.jpg.
  Date range and sort: most new photos carry a camera date between 2024 and 2025
  (the dates were added for this demo).

Credits:
the original photos are from Unsplash (https://unsplash.com/license),
downloaded through Lorem Picsum (https://picsum.photos). The copies were made from them.

norway-fjord.jpg - photo by Alexey Topolyanskiy - https://unsplash.com/photos/-oWyJoSqBRM
pug-in-blanket.jpg - photo by Matthew Wiebe - https://unsplash.com/photos/U5rMrSI7Pn4
strawberries.jpg - photo by veeterzy - https://unsplash.com/photos/OJJIaFZOeX4
another-pug-in-blanket.jpg - photo by Matthew Wiebe - https://unsplash.com/photos/2Ts5HnA67k8
waterfall-rainbow.jpg - photo by Jared Erondu - https://unsplash.com/photos/j4PaE7E2_Ws
forest-waterfall.jpg - photo by Andrew Coelho - https://unsplash.com/photos/VB-w_3dnyvI
city-skyline.jpg - photo by Kevin Young - https://unsplash.com/photos/-icmOdYWXuQ
jellyfish.jpg - photo by Marat Gilyadzinov - https://unsplash.com/photos/wpTWYBll4_w
coffee.jpg - photo by Carli Jean - https://unsplash.com/photos/UWRqlJcDCXA
black-puppy.jpg - photo by AndrÃ© Spieker - https://unsplash.com/photos/8wTPqxlnKM4
castle.jpg - photo by Rachel Davis - https://unsplash.com/photos/tn2rBnvIl9I
walruses.jpg - photo by Jay Ruzesky - https://unsplash.com/photos/h13Y8vyIXNU

AI demo photos (Wikimedia Commons; resized):
taj-mahal-garden-view.jpg - Yann; edited by King of Hearts - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:Taj_Mahal,_Agra,_India_edit2.jpg
taj-mahal-sunset.jpg - Muhammad Mahdi Karim, Stitching assisted by Benh - GFDL 1.2 - https://commons.wikimedia.org/wiki/File:Taj_Mahal_Sunset.jpg
taj-mahal-through-arch.jpg - Diego Delso - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:El_Taj_Mahal-Agra_India0023.JPG
taj-mahal-march.jpg - Dhirad, picture edited by J. A. Knudsen - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Taj_Mahal_in_March_2004.jpg
cat-in-snow.jpg - Von.grzanka - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Felis_catus-cat_on_snow.jpg
cat-sitting.jpg - Alvesgaspar - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Cat_November_2010-1a.jpg
cat-close-up.jpg - Augustus Binu : flickr - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Domestic_Cat_Face_Shot.jpg
people-biden-2021.jpg - The White House - Public domain - https://commons.wikimedia.org/wiki/File:Joe_Biden_official_portrait,_2021.jpg
people-biden-2013.jpg - The White House from Washington, DC - Public domain - https://commons.wikimedia.org/wiki/File:Joe_Biden_official_portrait_2013_(cropped)_2.jpg
people-biden-portrait.jpg - The White House - Public domain - https://commons.wikimedia.org/wiki/File:Joe_Biden_portrait_2021.jpg
people-harris-senate.jpg - Renee Bouchard - Public domain - https://commons.wikimedia.org/wiki/File:Senator_Kamala_Harris_Official_Portrait.jpg
people-harris-vp.jpg - Lawrence Jackson - Public domain - https://commons.wikimedia.org/wiki/File:Kamala_Harris_Vice_Presidential_Portrait_(cropped).jpg
people-obama-oval-office.jpg - Official White House Photo by Pete Souza - Public domain - https://commons.wikimedia.org/wiki/File:President_Barack_Obama.jpg
people-obama-official.jpg - Pete Souza - CC BY 3.0 - https://commons.wikimedia.org/wiki/File:Official_portrait_of_Barack_Obama.jpg
people-obama-with-cabinet.jpg - Chuck Kennedy (White House) - Public domain - https://commons.wikimedia.org/wiki/File:President_Barack_Obama_with_full_cabinet_09-10-09.jpg

More photos from Unsplash (https://unsplash.com/license), downloaded through Lorem Picsum:
beach-crowd.jpg - photo by Tina Rataj - https://unsplash.com/photos/pwaaqfoMibI
beach-misty-morning.jpg - photo by Christopher Sardegna - https://unsplash.com/photos/x_jTtMOOMd4
beach-steps.jpg - photo by Beto Galetto - https://unsplash.com/photos/RL0l7Zk5PxU
beach-palm-trees.jpg - photo by Paula Borowska - https://unsplash.com/photos/04paG2PxKGs
waves-on-rocks.jpg - photo by Angelina Odemchuk - https://unsplash.com/photos/lp0IFw6YqZg
dachshunds-in-grass.jpg - photo by Noel Lopez - https://unsplash.com/photos/BjelfpszQDw
leopard.jpg - photo by Martyn Seddon - https://unsplash.com/photos/7iB4OZDlRok
highland-cow.jpg - photo by Elias Carlsson - https://unsplash.com/photos/wSb8d-ke5-4
alps-ridge.jpg - photo by Aleksandra Boguslawska - https://unsplash.com/photos/XeCvtUX-AE0
snowy-mountain-lake.jpg - photo by Paul E. Harrer - https://unsplash.com/photos/TI-B-TNYJMU
snowy-peaks.jpg - photo by Sylwia Bartyzel - https://unsplash.com/photos/iOPsLuogRao
snowy-forest.jpg - photo by Sylwia Bartyzel - https://unsplash.com/photos/OdAqbedkfiA
hiker-in-valley.jpg - photo by Danka & Peter - https://unsplash.com/photos/tvicgTdh7Fg
mountain-road.jpg - photo by Alex Talmon - https://unsplash.com/photos/6iat9p85VnQ
lake-and-mountains.jpg - photo by Matteo Minelli - https://unsplash.com/photos/hlnucYOsL-c
london-at-night.jpg - photo by Vadim Sherbakov - https://unsplash.com/photos/xS_RzdD5CFE
new-york-skyline.jpg - photo by Anders JildÃ©n - https://unsplash.com/photos/yb0Qs65aZmc
brooklyn-bridge-night.jpg - photo by Anders JildÃ©n - https://unsplash.com/photos/nrLtvA05jk8
manhattan-from-brooklyn.jpg - photo by Namphuong Van - https://unsplash.com/photos/hfIheOEJp9M
bruges-canal.jpg - photo by Linh Nguyen - https://unsplash.com/photos/agkblvPff5U
paris-eiffel-tower.jpg - photo by Laura Liberal - https://unsplash.com/photos/_py5wlZTI2c
chateau-de-chambord.jpg - photo by Vadim Sherbakov - https://unsplash.com/photos/KSyemQIWwP8
cambridge-college.jpg - photo by Vadim Sherbakov - https://unsplash.com/photos/d6ebY-faOO0
sunset-over-field.jpg - photo by Kenneth Thewissen - https://unsplash.com/photos/D76DklsG-5U
sunset-runner.jpg - photo by Linh Nguyen - https://unsplash.com/photos/J8k-gzI0Zy0
farm-at-sunrise.jpg - photo by Philipp Reiner - https://unsplash.com/photos/qPJ6eRAMmCM
desert-dunes-dusk.jpg - photo by Tim de Groot - https://unsplash.com/photos/yNGQ830uFB4
desert-dunes.jpg - photo by Dyaa Eldin Moustafa - https://unsplash.com/photos/mR_HR8NZwg8
raspberries.jpg - photo by Ben Moore - https://unsplash.com/photos/pJILiyPdrXI
tea-pot.jpg - photo by Vee O - https://unsplash.com/photos/hGO27G5tZJ8
old-camera.jpg - photo by Nicola Perantoni - https://unsplash.com/photos/irUQaBK3ydI
fishing-boats.jpg - photo by Martin Wessely - https://unsplash.com/photos/GDvSktiPIQQ
pelican-burst-*.jpg - made from a photo by Yair Hazout - https://unsplash.com/photos/Y-eIZ3g8_ko

More photos from Wikimedia Commons (resized):
food-biryani.jpg - Dheerajk88 - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:Chicken_Hyderabadi_Biryani.JPG
food-masala-dosa.jpg - Marajozkee - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:Masala_dosa_01.jpg
food-pizza.jpg - Mario56 - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Margherita_Originale.JPG
food-sushi.jpg - chidorian from Japan - CC BY-SA 2.0 - https://commons.wikimedia.org/wiki/File:Sushi_platter.jpg
food-pancakes.jpg - Herson Rodriguez hero - CC0 - https://commons.wikimedia.org/wiki/File:Pancakes_with_Berries_(Unsplash).jpg
people-kalpana-chawla-orange-suit.jpg - NASA - Public domain - https://commons.wikimedia.org/wiki/File:Kalpana_Chawla,_NASA_photo_portrait_in_orange_suit.jpg
people-kalpana-chawla-portrait.jpg - NASA - Public domain - https://commons.wikimedia.org/wiki/File:Kalpana_Chawla,_official_portrait.jpg
people-kalpana-chawla-with-crew.jpg - NASA official photo - Public domain - https://commons.wikimedia.org/wiki/File:STS-107_Crew_portrait.jpg
people-sunita-williams-spacesuit.jpg - NASA - Public domain - https://commons.wikimedia.org/wiki/File:Sunita_Williams.jpg
people-sunita-williams-2018.jpg - Robert Markowitz - Public domain - https://commons.wikimedia.org/wiki/File:Sunita_Williams_in_2018.jpg
people-sunita-williams-with-crew.jpg - NASA Kennedy Space Center / NASA/JSC - Public domain - https://commons.wikimedia.org/wiki/File:Boeing_CFT_Crew_Portrait-Sunita_Williams_and_Barry_Wilmore_(KSC-20240404-PH-NAS01_0001).jpg

Photos with text (Wikimedia Commons; resized):
las-vegas-sign.jpg - Christian David - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:Welcome_to_Fabulous_Las_Vegas_sign,_Nevada_-_April_2026.jpg
malibu-feed-bin.jpg - CaliforniaFoghorn - CC BY 4.0 - https://commons.wikimedia.org/wiki/File:Malibu_Feed_Bin_sign_and_storefront_2024.jpg
parangipettai-railway-station.jpg - Ahamedpno - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:Parangipettai_(India)_railway_station_name_board_2024-01-02.jpg
stop-sign-and-mailboxes.jpg - Tuxyso - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Letterboxes_Ocotillo_Wells_2013_Crop.jpg
