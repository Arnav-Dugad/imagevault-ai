ImageVault demo photos
======================

Upload all of these photos to ImageVault and open the Duplicates page.

What ImageVault should find:
  * norway-fjord (copy).jpg        exact copy of norway-fjord.jpg
  * norway-fjord-whatsapp.jpg      resized + compressed (like sending it on WhatsApp)
  * norway-fjord-edited.jpg        brightness and contrast edited
  * pug-in-blanket-small.jpg       resized copy
  * strawberries-compressed.jpg    heavily compressed copy

Look-alike photos that should NOT be matched (different shots of a similar subject):
  * pug-in-blanket.jpg vs another-pug-in-blanket.jpg
  * waterfall-rainbow.jpg vs forest-waterfall.jpg

Credits: the original photos are from Unsplash (https://unsplash.com/license),
downloaded through Lorem Picsum (https://picsum.photos). The copies were made from them.

norway-fjord.jpg - photo by Alexey Topolyanskiy - https://unsplash.com/photos/-oWyJoSqBRM
pug-in-blanket.jpg - photo by Matthew Wiebe - https://unsplash.com/photos/U5rMrSI7Pn4
strawberries.jpg - photo by veeterzy - https://unsplash.com/photos/OJJIaFZOeX4
another-pug-in-blanket.jpg - photo by Matthew Wiebe - https://unsplash.com/photos/2Ts5HnA67k8
waterfall-rainbow.jpg - photo by Jared Erondu - https://unsplash.com/photos/j4PaE7E2_Ws
forest-waterfall.jpg - photo by Andrew Coelho - https://unsplash.com/photos/VB-w_3dnyvI
city-skyline.jpg - photo by Kevin Young - https://unsplash.com/photos/-icmOdYWXuQ
jellyfish.jpg - photo by Marat Gilyadzinov - https://unsplash.com/photos/wpTWYBll4_w
coffee.jpg - photo by Carli Jean - https://unsplash.com/photos/UWRqlJcDCXA
black-puppy.jpg - photo by AndrÃ© Spieker - https://unsplash.com/photos/8wTPqxlnKM4
castle.jpg - photo by Rachel Davis - https://unsplash.com/photos/tn2rBnvIl9I
walruses.jpg - photo by Jay Ruzesky - https://unsplash.com/photos/h13Y8vyIXNU
