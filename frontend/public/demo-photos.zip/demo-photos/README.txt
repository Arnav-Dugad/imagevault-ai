ImageVault demo photos
======================

Upload all of these photos to ImageVault and open the Duplicates page.

What ImageVault should find:
  * norway-fjord (copy).jpg        exact copy of norway-fjord.jpg
  * norway-fjord-whatsapp.jpg      resized + compressed (like sending it on WhatsApp)
  * norway-fjord-edited.jpg        brightness and contrast edited
  * pug-in-blanket-small.jpg       resized copy
  * strawberries-compressed.jpg    heavily compressed copy

Look-alike photos that should NOT be matched (different shots of a similar subject):
  * pug-in-blanket.jpg vs another-pug-in-blanket.jpg
  * waterfall-rainbow.jpg vs forest-waterfall.jpg

Free AI demo (People, smart search, "same subject"):
  * taj-mahal-*.jpg      4 different shots of the Taj Mahal: grouped under
                         Duplicates > "Same subject, different shot" (not as copies)
  * cat-*.jpg            3 different cats: grouped as the same kind of subject
  * people-*.jpg         official portraits: the People page groups each person,
                         and finds Obama again among 20+ faces in the cabinet photo
  * Smart search: switch the Photos search to "Smart" and try "cat", "a palace at sunset",
    "strawberries" or "a man in a suit"

Tip for your demo: add a few selfies of your team members (with their permission)
to show People recognising you.

Credits: the original photos are from Unsplash (https://unsplash.com/license),
downloaded through Lorem Picsum (https://picsum.photos). The copies were made from them.

norway-fjord.jpg - photo by Alexey Topolyanskiy - https://unsplash.com/photos/-oWyJoSqBRM
pug-in-blanket.jpg - photo by Matthew Wiebe - https://unsplash.com/photos/U5rMrSI7Pn4
strawberries.jpg - photo by veeterzy - https://unsplash.com/photos/OJJIaFZOeX4
another-pug-in-blanket.jpg - photo by Matthew Wiebe - https://unsplash.com/photos/2Ts5HnA67k8
waterfall-rainbow.jpg - photo by Jared Erondu - https://unsplash.com/photos/j4PaE7E2_Ws
forest-waterfall.jpg - photo by Andrew Coelho - https://unsplash.com/photos/VB-w_3dnyvI
city-skyline.jpg - photo by Kevin Young - https://unsplash.com/photos/-icmOdYWXuQ
jellyfish.jpg - photo by Marat Gilyadzinov - https://unsplash.com/photos/wpTWYBll4_w
coffee.jpg - photo by Carli Jean - https://unsplash.com/photos/UWRqlJcDCXA
black-puppy.jpg - photo by AndrÃ© Spieker - https://unsplash.com/photos/8wTPqxlnKM4
castle.jpg - photo by Rachel Davis - https://unsplash.com/photos/tn2rBnvIl9I
walruses.jpg - photo by Jay Ruzesky - https://unsplash.com/photos/h13Y8vyIXNU

AI demo photos (Wikimedia Commons; resized):
taj-mahal-garden-view.jpg - Yann; edited by King of Hearts - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:Taj_Mahal,_Agra,_India_edit2.jpg
taj-mahal-sunset.jpg - Muhammad Mahdi Karim, Stitching assisted by Benh - GFDL 1.2 - https://commons.wikimedia.org/wiki/File:Taj_Mahal_Sunset.jpg
taj-mahal-through-arch.jpg - Diego Delso - CC BY-SA 4.0 - https://commons.wikimedia.org/wiki/File:El_Taj_Mahal-Agra_India0023.JPG
taj-mahal-march.jpg - Dhirad, picture edited by J. A. Knudsen - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Taj_Mahal_in_March_2004.jpg
cat-in-snow.jpg - Von.grzanka - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Felis_catus-cat_on_snow.jpg
cat-sitting.jpg - Alvesgaspar - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Cat_November_2010-1a.jpg
cat-close-up.jpg - Augustus Binu : flickr - CC BY-SA 3.0 - https://commons.wikimedia.org/wiki/File:Domestic_Cat_Face_Shot.jpg
people-biden-2021.jpg - The White House - Public domain - https://commons.wikimedia.org/wiki/File:Joe_Biden_official_portrait,_2021.jpg
people-biden-2013.jpg - The White House from Washington, DC - Public domain - https://commons.wikimedia.org/wiki/File:Joe_Biden_official_portrait_2013_(cropped)_2.jpg
people-biden-portrait.jpg - The White House - Public domain - https://commons.wikimedia.org/wiki/File:Joe_Biden_portrait_2021.jpg
people-harris-senate.jpg - Renee Bouchard - Public domain - https://commons.wikimedia.org/wiki/File:Senator_Kamala_Harris_Official_Portrait.jpg
people-harris-vp.jpg - Lawrence Jackson - Public domain - https://commons.wikimedia.org/wiki/File:Kamala_Harris_Vice_Presidential_Portrait_(cropped).jpg
people-obama-oval-office.jpg - Official White House Photo by Pete Souza - Public domain - https://commons.wikimedia.org/wiki/File:President_Barack_Obama.jpg
people-obama-official.jpg - Pete Souza - CC BY 3.0 - https://commons.wikimedia.org/wiki/File:Official_portrait_of_Barack_Obama.jpg
people-obama-with-cabinet.jpg - Chuck Kennedy (White House) - Public domain - https://commons.wikimedia.org/wiki/File:President_Barack_Obama_with_full_cabinet_09-10-09.jpg
